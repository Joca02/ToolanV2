<?php

namespace App\Enum;

enum PostLoadType {
    case ALL;
    case HOME;
    case PROFILE;
}

