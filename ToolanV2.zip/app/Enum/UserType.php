<?php
namespace App\Enum;

enum UserType: string {
    case USER='user';
    case ADMIN='admin';
}
