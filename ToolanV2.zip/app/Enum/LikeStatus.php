<?php

namespace App\Enum;

enum LikeStatus: string {
   case LIKED='liked';
   case NOT_LIKED='notLiked';
}
